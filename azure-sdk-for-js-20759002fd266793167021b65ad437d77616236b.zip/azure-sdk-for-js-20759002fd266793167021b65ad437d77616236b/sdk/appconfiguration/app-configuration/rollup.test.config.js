import * as base from "./rollup.base.config";

export default [base.nodeConfig(true)];
