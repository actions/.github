# @local/site-assets

The purpose of this repo is to store assets such as the corporate logo,
stylesheets, etc. used by the site.